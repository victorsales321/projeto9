var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["0dd944d8-38bc-4771-8ec1-69528e5b4ad0","60efb665-d838-4f5d-a178-b30b46a54c1e","9c75e2e7-42d7-4a78-bad9-acfdbc76abc7","d9962539-d6cb-4f2a-84a1-47c1013ba7e2","9015674c-0988-47bb-8889-03dd6564445a"],"propsByKey":{"0dd944d8-38bc-4771-8ec1-69528e5b4ad0":{"name":"car_red_1","sourceUrl":"assets/api/v1/animation-library/gamelab/PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu/category_vehicles/car_red.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu/category_vehicles/car_red.png"},"60efb665-d838-4f5d-a178-b30b46a54c1e":{"name":"desert_road_1","sourceUrl":"assets/api/v1/animation-library/gamelab/uexnVGl6IX_C6YzQENPPXtel_lCwoG7F/category_backgrounds/desert_road.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"uexnVGl6IX_C6YzQENPPXtel_lCwoG7F","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uexnVGl6IX_C6YzQENPPXtel_lCwoG7F/category_backgrounds/desert_road.png"},"9c75e2e7-42d7-4a78-bad9-acfdbc76abc7":{"name":"blue_hoodie_backpack_1","sourceUrl":"assets/api/v1/animation-library/gamelab/zPUFCzpi9NNCKu799uw5h7NO1Y13PEFP/category_people/blue_hoodie_backpack.png","frameSize":{"x":119,"y":383},"frameCount":1,"looping":true,"frameDelay":2,"version":"zPUFCzpi9NNCKu799uw5h7NO1Y13PEFP","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":119,"y":383},"rootRelativePath":"assets/api/v1/animation-library/gamelab/zPUFCzpi9NNCKu799uw5h7NO1Y13PEFP/category_people/blue_hoodie_backpack.png"},"d9962539-d6cb-4f2a-84a1-47c1013ba7e2":{"name":"yellow_shirt_cast_1","sourceUrl":"assets/api/v1/animation-library/gamelab/j4dIZ4NbbPf0tn0WcdEPq70sAkFNMI_T/category_people/yellow_shirt_cast.png","frameSize":{"x":177,"y":398},"frameCount":1,"looping":true,"frameDelay":2,"version":"j4dIZ4NbbPf0tn0WcdEPq70sAkFNMI_T","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":177,"y":398},"rootRelativePath":"assets/api/v1/animation-library/gamelab/j4dIZ4NbbPf0tn0WcdEPq70sAkFNMI_T/category_people/yellow_shirt_cast.png"},"9015674c-0988-47bb-8889-03dd6564445a":{"name":"grey_shirt2_1","sourceUrl":"assets/api/v1/animation-library/gamelab/t44eFFNKurL6603QnBdIgqQ0CWopoOaC/category_people/grey_shirt2.png","frameSize":{"x":143,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"t44eFFNKurL6603QnBdIgqQ0CWopoOaC","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":143,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/t44eFFNKurL6603QnBdIgqQ0CWopoOaC/category_people/grey_shirt2.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var fundo=createSprite(200,200,400,400)
fundo.setAnimation("desert_road_1")

var car=createSprite(182,366,40,40)
car.setAnimation("car_red_1")
car.scale=0.5
var net=createSprite(200,5,200,20)
net.shapeColor="red"
var pessoa1=createSprite(284,267,20,20)
var pessoa2=createSprite(89,192,20,20)
var pessoa3=createSprite(256,97,20,20)

pessoa1.setAnimation("blue_hoodie_backpack_1")
pessoa1.scale=0.2
pessoa2.setAnimation("grey_shirt2_1")
pessoa2.scale=0.2
pessoa3.setAnimation("yellow_shirt_cast_1")
pessoa3.scale=0.2

pessoa1.velocityX=+10
pessoa2.velocityX=-10
pessoa3.velocityX=+10





createEdgeSprites()




function draw() {

pessoa1.bounceOff(edges)
 pessoa2.bounceOff(edges)
 pessoa3.bounceOff(edges)
 car.bounceOff(edges)
 if(keyDown(UP_ARROW)){
  car.y=car.y-6
}

if(keyDown(DOWN_ARROW)){
  car.y=car.y+6
}

if(keyDown(LEFT_ARROW)){
  car.x=car.x-6
}

if(keyDown(RIGHT_ARROW)){
  car.x=car.x+6
}
if(car.isTouching(pessoa1)|| car.isTouching(pessoa2)|| car.isTouching(pessoa3)){
  playSound("assets/category_explosion/puzzle_game_break_magic_02.mp3")
  car.x=182
  car.y=366
  
}
if(car.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  car.x=200
  car.y=345
  
}

  
   
   
 drawSprites() 
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
